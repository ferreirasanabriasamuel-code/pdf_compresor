# Reglas ProGuard — la app no usa reflexión sobre sus modelos,
# Compose y Kotlin ya traen sus reglas consumidoras.
