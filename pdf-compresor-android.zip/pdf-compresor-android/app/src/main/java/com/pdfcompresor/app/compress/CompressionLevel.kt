package com.pdfcompresor.app.compress

/**
 * Niveles de compresión. Cada nivel combina resolución de re-muestreo (dpi)
 * y calidad JPEG de las páginas re-renderizadas — la misma técnica de las
 * apps de referencia, pero 100% offline.
 */
enum class CompressionLevel(
    val titulo: String,
    val descripcion: String,
    val dpi: Int,
    val jpegQuality: Int
) {
    LIGERO(
        "Ligero",
        "Máxima calidad. Ideal si el PDF tiene texto y gráficos finos.",
        dpi = 150,
        jpegQuality = 80
    ),
    MEDIO(
        "Medio",
        "Equilibrado. Recomendado para tareas y proyectos.",
        dpi = 110,
        jpegQuality = 60
    ),
    AGRESIVO(
        "Agresivo",
        "Peso mínimo. Ideal para escaneos y presentaciones con fotos.",
        dpi = 85,
        jpegQuality = 45
    )
}
