package com.pdfcompresor.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pdfcompresor.app.data.LibItem
import com.pdfcompresor.app.ui.PdfIntents
import com.pdfcompresor.app.ui.components.IconoCarpeta
import com.pdfcompresor.app.ui.components.IconoPdfBox
import com.pdfcompresor.app.ui.components.TituloPagina
import com.pdfcompresor.app.ui.components.formatBytes
import com.pdfcompresor.app.ui.theme.Borde
import com.pdfcompresor.app.ui.theme.Rojo
import com.pdfcompresor.app.ui.theme.RojoFuerte
import com.pdfcompresor.app.ui.theme.Superficie
import com.pdfcompresor.app.ui.theme.Superficie3
import com.pdfcompresor.app.ui.theme.TextoAlto
import com.pdfcompresor.app.ui.theme.TextoBajo
import com.pdfcompresor.app.ui.theme.TextoMedio
import com.pdfcompresor.app.viewmodel.MainViewModel
import com.pdfcompresor.app.viewmodel.MainViewModel.Companion.fecha
import kotlin.math.roundToInt

@Composable
fun LibraryScreen(vm: MainViewModel) {
    val consulta by vm.consultaLib.collectAsStateWithLifecycle()
    val biblioteca by vm.biblioteca.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) { vm.refreshLibrary() }

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp)
    ) {
        Spacer(Modifier.height(14.dp))
        TituloPagina("Biblioteca")

        Spacer(Modifier.height(14.dp))

        // ── Carpeta donde se guardan los PDF comprimidos ──
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Superficie)
                .border(1.dp, Borde, RoundedCornerShape(14.dp))
                .padding(horizontal = 13.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(IconoCarpeta, null, tint = Rojo, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(9.dp))
            Text(
                buildAnnotatedString {
                    append("Descargas / ")
                    withStyle(SpanStyle(color = TextoAlto, fontWeight = FontWeight.SemiBold)) {
                        append("PDF compresor")
                    }
                    append("  ·  ${biblioteca.size} archivos")
                },
                fontSize = 12.sp, color = TextoMedio,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(Modifier.height(14.dp))

        // ── Búsqueda ──
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Superficie)
                .border(1.dp, Borde, RoundedCornerShape(14.dp))
                .padding(horizontal = 13.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Search, null, tint = TextoBajo, modifier = Modifier.size(15.dp))
            Spacer(Modifier.width(9.dp))
            Box(Modifier.weight(1f)) {
                if (consulta.isEmpty()) {
                    Text("Buscar por nombre…", fontSize = 13.5.sp, color = TextoBajo)
                }
                BasicTextField(
                    value = consulta,
                    onValueChange = { vm.setConsulta(it) },
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 13.5.sp, color = TextoAlto),
                    cursorBrush = SolidColor(Rojo),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(Modifier.height(14.dp))

        // ── Lista ──
        val filtrada = vm.bibliotecaFiltrada()
        if (filtrada.isEmpty()) {
            Column(
                Modifier.fillMaxWidth().padding(vertical = 44.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    IconoCarpeta, null,
                    tint = Superficie3, modifier = Modifier.size(44.dp)
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    if (consulta.isEmpty()) "Aún no hay archivos" else "Sin resultados",
                    fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextoMedio
                )
                Text(
                    if (consulta.isEmpty()) "los PDF que comprimas aparecerán aquí"
                    else "prueba con otro nombre",
                    fontSize = 12.sp, color = TextoBajo, modifier = Modifier.padding(top = 4.dp)
                )
            }
        } else {
            filtrada.forEach { item ->
                FilaLib(item,
                    onAbrir = { PdfIntents.abrir(vm.getApplication(), item) },
                    onCompartir = { PdfIntents.compartir(vm.getApplication(), item) },
                    onEliminar = { vm.eliminar(item) }
                )
                Spacer(Modifier.height(10.dp))
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun FilaLib(
    item: LibItem,
    onAbrir: () -> Unit,
    onCompartir: () -> Unit,
    onEliminar: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Superficie)
            .border(1.dp, Borde, RoundedCornerShape(14.dp))
            .clickable(onClick = onAbrir)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconoPdfBox()
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(
                item.name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                color = TextoAlto, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                subLinea(item),
                fontSize = 11.sp, color = TextoBajo, modifier = Modifier.padding(top = 3.dp)
            )
        }
        Spacer(Modifier.width(8.dp))
        AccionLib(Icons.Filled.Share, "Compartir", onCompartir)
        Spacer(Modifier.width(6.dp))
        AccionLib(Icons.Filled.Delete, "Eliminar", onEliminar)
    }
}

/** «0.81 MB −65% · 10 pág · 13 nov 2026, 21:04» con el ahorro en rojo. */
private fun subLinea(item: LibItem) = buildAnnotatedString {
    append(formatBytes(item.sizeBytes))
    val antes = item.originalBytes ?: 0L
    if (antes > 0 && item.sizeBytes > 0) {
        val pct = ((1 - item.sizeBytes.toDouble() / antes) * 100).roundToInt()
        if (pct > 0) {
            withStyle(SpanStyle(color = RojoFuerte, fontWeight = FontWeight.Bold)) {
                append("  −$pct%")
            }
        }
    }
    item.pages?.let { append(" · $it pág") }
    append(" · ${fecha(item.dateModified)}")
}

@Composable
private fun AccionLib(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(30.dp)
            .clip(RoundedCornerShape(9.dp))
            .background(Superficie3)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, desc, tint = TextoMedio, modifier = Modifier.size(14.dp))
    }
}
