package com.pdfcompresor.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pdfcompresor.app.ui.components.IconoCarpeta
import com.pdfcompresor.app.ui.components.IconoDocumento
import com.pdfcompresor.app.ui.screens.HomeScreen
import com.pdfcompresor.app.ui.screens.LibraryScreen
import com.pdfcompresor.app.ui.screens.ResultScreen
import com.pdfcompresor.app.ui.theme.Borde
import com.pdfcompresor.app.ui.theme.Fondo
import com.pdfcompresor.app.ui.theme.PDFCompresorTheme
import com.pdfcompresor.app.ui.theme.Rojo
import com.pdfcompresor.app.ui.theme.TextoBajo
import com.pdfcompresor.app.viewmodel.MainViewModel
import com.pdfcompresor.app.viewmodel.Pantalla

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PDFCompresorTheme {
                AppRoot()
            }
        }
    }
}

@Composable
fun AppRoot() {
    val vm: MainViewModel = viewModel()
    val context = LocalContext.current
    val pantalla by vm.pantalla.collectAsStateWithLifecycle()
    var permisoPendiente by remember { mutableStateOf(false) }

    // El selector del sistema permite marcar uno o varios PDF.
    val pickDocs = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris -> if (!uris.isNullOrEmpty()) vm.onFilesPicked(uris) }

    val pedirPermiso = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok ->
        if (ok && permisoPendiente) {
            permisoPendiente = false
            vm.comprimir()
        } else if (!ok) {
            Toast.makeText(
                context,
                "Se necesita permiso de almacenamiento para guardar en Descargas",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    fun abrirSelector() {
        pickDocs.launch(arrayOf("application/pdf"))
    }

    fun iniciarCompresion() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            vm.comprimir()
        } else if (ContextCompat.checkSelfPermission(
                context, Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            vm.comprimir()
        } else {
            permisoPendiente = true
            pedirPermiso.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Fondo)
            .systemBarsPadding()
    ) {
        Box(Modifier.weight(1f)) {
            when (pantalla) {
                Pantalla.Inicio -> HomeScreen(vm, ::abrirSelector, ::iniciarCompresion)
                Pantalla.Resultado -> ResultScreen(vm)
                Pantalla.Biblioteca -> LibraryScreen(vm)
            }
        }
        BarraInferior(
            enBiblioteca = pantalla == Pantalla.Biblioteca,
            onComprimir = { vm.irA(Pantalla.Inicio) },
            onBiblio = { vm.refreshLibrary(); vm.irA(Pantalla.Biblioteca) }
        )
    }
}

/** Barra inferior del prototipo: Comprimir · Biblioteca. */
@Composable
private fun BarraInferior(
    enBiblioteca: Boolean,
    onComprimir: () -> Unit,
    onBiblio: () -> Unit
) {
    Column {
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(Borde)
        )
        Row(
            Modifier
                .fillMaxWidth()
                .background(Color(0xF2101012))
                .padding(horizontal = 26.dp, vertical = 8.dp)
        ) {
            ItemNav(
                "Comprimir", IconoDocumento,
                seleccionado = !enBiblioteca,
                modifier = Modifier.weight(1f),
                onClick = onComprimir
            )
            ItemNav(
                "Biblioteca", IconoCarpeta,
                seleccionado = enBiblioteca,
                modifier = Modifier.weight(1f),
                onClick = onBiblio
            )
        }
    }
}

@Composable
private fun ItemNav(
    etiqueta: String,
    icono: ImageVector,
    seleccionado: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier.clickable(onClick = onClick).padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            icono, contentDescription = etiqueta,
            tint = if (seleccionado) Rojo else TextoBajo,
            modifier = Modifier.size(21.dp)
        )
        Spacer(Modifier.height(4.dp))
        Text(
            etiqueta, fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold,
            color = if (seleccionado) Rojo else TextoBajo
        )
    }
}
