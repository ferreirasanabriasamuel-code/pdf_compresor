package com.pdfcompresor.app.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.pdfcompresor.app.compress.PdfCompressor
import java.io.File

/** Un archivo dentro de la biblioteca (carpeta «PDF compresor»). */
data class LibItem(
    val uri: Uri?,       // content:// (Android 10+)
    val file: File?,     // ruta directa (Android 8–9)
    val name: String,
    val sizeBytes: Long,
    val dateModified: Long, // milisegundos
    val originalBytes: Long? = null, // registro de la compresión (para «−%»)
    val pages: Int? = null
) {
    fun contentOrFile(context: Context): Uri {
        if (uri != null) return uri
        return androidx.core.content.FileProvider.getUriForFile(
            context,
            context.packageName + ".fileprovider",
            file!!
        )
    }
}

/**
 * Acceso a la biblioteca de archivos comprimidos.
 * - Android 10+ : consulta MediaStore (Descargas/PDF compresor) — no requiere permisos.
 * - Android 8–9 : lista el directorio Descargas/PDF compresor.
 * Los datos de «−%» y páginas salen del [CompressionLog].
 */
object LibraryRepository {

    private val RELATIVE_PATH = Environment.DIRECTORY_DOWNLOADS + "/" + PdfCompressor.FOLDER_NAME

    fun list(context: Context): List<LibItem> {
        val base = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            listMediaStore(context)
        } else {
            listLegacy()
        }
        // Enriquecer con el registro de compresión (peso original, páginas)
        return base.map { item ->
            CompressionLog.get(context, item.name)?.let { (antes, paginas) ->
                item.copy(originalBytes = antes, pages = paginas)
            } ?: item
        }
    }

    private fun listMediaStore(context: Context): List<LibItem> {
        val out = mutableListOf<LibItem>()
        val resolver = context.contentResolver
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_MODIFIED
        )
        val selection = "${MediaStore.MediaColumns.RELATIVE_PATH}=?"
        val args = arrayOf("$RELATIVE_PATH/")
        resolver.query(
            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            projection, selection, args,
            "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val nmCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val szCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val dtCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)
            while (c.moveToNext()) {
                out.add(
                    LibItem(
                        uri = ContentUris.withAppendedId(
                            MediaStore.Downloads.EXTERNAL_CONTENT_URI, c.getLong(idCol)
                        ),
                        file = null,
                        name = c.getString(nmCol) ?: "",
                        sizeBytes = c.getLong(szCol),
                        dateModified = c.getLong(dtCol) * 1000L
                    )
                )
            }
        }
        return out
    }

    private fun listLegacy(): List<LibItem> {
        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            PdfCompressor.FOLDER_NAME
        )
        return dir.listFiles { f -> f.isFile && f.name.endsWith(".pdf") }
            ?.sortedByDescending { it.lastModified() }
            ?.map {
                LibItem(
                    uri = null, file = it, name = it.name,
                    sizeBytes = it.length(), dateModified = it.lastModified()
                )
            } ?: emptyList()
    }

    fun delete(context: Context, item: LibItem) {
        try {
            if (item.uri != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                context.contentResolver.delete(item.uri, null, null)
            } else {
                item.file?.delete()
            }
        } catch (_: Exception) { /* ignorar */ }
    }
}
