package com.pdfcompresor.app.compress

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import com.pdfcompresor.app.data.CompressionLog
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.roundToInt

/** Resultado de comprimir un PDF. */
data class CompressionResult(
    val outputUri: Uri?,      // Uri de MediaStore (Android 10+)
    val outputFile: File?,    // Fichero directo (Android 8–9)
    val outputName: String,   // Nombre final (MediaStore puede renombrar si ya existía)
    val beforeBytes: Long,
    val afterBytes: Long,
    val pages: Int
)

/**
 * Motor de compresión: abre el PDF original con [PdfRenderer], re-renderiza cada
 * página a JPEG con la resolución y calidad del nivel elegido y reconstruye el
 * documento con [PdfDocument]. Todo ocurre en el dispositivo, sin subir nada.
 */
object PdfCompressor {

    const val FOLDER_NAME = "PDF compresor"
    const val SUFFIX = "_comprimido"
    private const val MIME_PDF = "application/pdf"

    suspend fun compress(
        context: Context,
        sourceUri: Uri,
        sourceName: String,
        level: CompressionLevel,
        onProgress: (pageDone: Int, pageTotal: Int) -> Unit = { _, _ -> }
    ): CompressionResult {
        val resolver = context.contentResolver

        val pfd = resolver.openFileDescriptor(sourceUri, "r")
            ?: throw IllegalStateException("No se pudo abrir el PDF seleccionado.")
        val beforeBytes = pfd.statSize

        val doc = PdfDocument()
        try {
            val renderer = PdfRenderer(pfd)
            try {
                val total = renderer.pageCount
                if (total == 0) throw IllegalStateException("El PDF no tiene páginas.")
                val scale = level.dpi / 72f

                for (i in 0 until total) {
                    onProgress(i, total)
                    val page = renderer.openPage(i)
                    try {
                        val pxW = (page.width * scale).roundToInt().coerceAtLeast(1)
                        val pxH = (page.height * scale).roundToInt().coerceAtLeast(1)

                        val bitmap = Bitmap.createBitmap(pxW, pxH, Bitmap.Config.ARGB_8888)
                        bitmap.eraseColor(android.graphics.Color.WHITE)
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)

                        val jpegBytes = ByteArrayOutputStream().use { bos ->
                            bitmap.compress(Bitmap.CompressFormat.JPEG, level.jpegQuality, bos)
                            bos.toByteArray()
                        }
                        bitmap.recycle()

                        val decoded = BitmapFactory.decodeByteArray(jpegBytes, 0, jpegBytes.size)
                        try {
                            val pageInfo = PdfDocument.PageInfo.Builder(
                                page.width, page.height, i + 1
                            ).create()
                            val pdfPage = doc.startPage(pageInfo)
                            val canvas = pdfPage.canvas
                            val paint = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG)
                            canvas.drawBitmap(
                                decoded, null,
                                RectF(0f, 0f, page.width.toFloat(), page.height.toFloat()),
                                paint
                            )
                            doc.finishPage(pdfPage)
                        } finally {
                            decoded.recycle()
                        }
                    } finally {
                        page.close()
                    }
                    onProgress(i + 1, total)
                }
            } finally {
                renderer.close()
            }

            val baseName = nombreSalida(sourceName)
            val res = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                guardarEnMediaStore(resolver, doc, baseName, beforeBytes, doc.pages.size)
            } else {
                guardarEnFichero(doc, baseName, beforeBytes, doc.pages.size)
            }
            // Registrar en la biblioteca: peso original y páginas para mostrar «−%»
            CompressionLog.put(context, res.outputName, beforeBytes, res.pages)
            return res
        } finally {
            doc.close()
            try { pfd.close() } catch (_: Exception) {}
        }
    }

    /** "Tarea3.pdf" → "Tarea3_comprimido.pdf" */
    fun nombreSalida(nombreOriginal: String): String {
        val sinExt = nombreOriginal.substringBeforeLast('.', nombreOriginal)
        return sinExt + SUFFIX + ".pdf"
    }

    /** Android 10+ : guarda en Descargas/PDF compresor vía MediaStore, sin permisos. */
    private fun guardarEnMediaStore(
        resolver: android.content.ContentResolver,
        doc: PdfDocument,
        baseName: String,
        beforeBytes: Long,
        pages: Int
    ): CompressionResult {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, baseName)
            put(MediaStore.MediaColumns.MIME_TYPE, MIME_PDF)
            put(
                MediaStore.MediaColumns.RELATIVE_PATH,
                Environment.DIRECTORY_DOWNLOADS + "/" + FOLDER_NAME
            )
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("No se pudo crear el archivo en Descargas.")

        resolver.openOutputStream(uri)?.use { doc.writeTo(it) }
            ?: throw IllegalStateException("No se pudo escribir el archivo comprimido.")

        values.clear()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        resolver.update(uri, values, null, null)

        // El nombre real (si ya existía, MediaStore añade "(1)", "(2)"…)
        val nombreFinal = queryDisplayName(resolver, uri) ?: baseName
        val size = querySize(resolver, uri)
        return CompressionResult(uri, null, nombreFinal, beforeBytes, size, pages)
    }

    /** Android 8–9 : guarda en Descargas/PDF compresor como fichero directo. */
    private fun guardarEnFichero(
        doc: PdfDocument, baseName: String, beforeBytes: Long, pages: Int
    ): CompressionResult {
        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            FOLDER_NAME
        )
        if (!dir.exists()) dir.mkdirs()
        var out = File(dir, baseName)
        var n = 1
        while (out.exists()) {
            out = File(dir, baseName.replace(".pdf", " ($n).pdf"))
            n++
        }
        FileOutputStream(out).use { doc.writeTo(it) }
        return CompressionResult(null, out, out.name, beforeBytes, out.length(), pages)
    }

    private fun queryDisplayName(resolver: android.content.ContentResolver, uri: Uri): String? =
        try {
            resolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (_: Exception) {
            null
        }

    private fun querySize(resolver: android.content.ContentResolver, uri: Uri): Long =
        try {
            resolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: 0L
        } catch (_: Exception) {
            0L
        }

    /** Renderiza la primera página de un PDF a un bitmap pequeño (vista previa). */
    fun renderPreview(context: Context, uri: Uri?, file: File?, maxW: Int = 300): Bitmap? {
        return try {
            val pfd: ParcelFileDescriptor? = when {
                uri != null -> context.contentResolver.openFileDescriptor(uri, "r")
                file != null -> ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                else -> null
            } ?: return null
            try {
                val renderer = PdfRenderer(pfd)
                try {
                    if (renderer.pageCount == 0) return null
                    val page = renderer.openPage(0)
                    try {
                        val ratio = page.height.toFloat() / page.width.toFloat()
                        val w = maxW
                        val h = (w * ratio).roundToInt()
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(android.graphics.Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                        bmp
                    } finally {
                        page.close()
                    }
                } finally {
                    renderer.close()
                }
            } finally {
                try { pfd.close() } catch (_: Exception) {}
            }
        } catch (_: Exception) {
            null
        }
    }
}
