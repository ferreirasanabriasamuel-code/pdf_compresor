package com.pdfcompresor.app.viewmodel

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pdfcompresor.app.compress.CompressionLevel
import com.pdfcompresor.app.compress.PdfCompressor
import com.pdfcompresor.app.data.LibItem
import com.pdfcompresor.app.data.LibraryRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class Pantalla {
    data object Inicio : Pantalla()
    data object Resultado : Pantalla()
    data object Biblioteca : Pantalla()
}

enum class EstadoJob { PENDIENTE, PROCESANDO, LISTO, ERROR }

data class JobItem(
    val uri: Uri,
    val nombre: String,
    val antesBytes: Long,
    val estado: EstadoJob = EstadoJob.PENDIENTE,
    val progreso: Float = 0f,          // 0..1 (páginas procesadas)
    val paginas: Int = 0,
    val despuesBytes: Long = 0L,
    val salidaUri: Uri? = null,
    val salidaFile: java.io.File? = null,
    val error: String? = null
)

data class ResultadoUi(
    val jobs: List<JobItem>,
    val totalAntes: Long,
    val totalDespues: Long,
    val thumbnail: ImageBitmap? = null
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val _pantalla = MutableStateFlow<Pantalla>(Pantalla.Inicio)
    val pantalla: StateFlow<Pantalla> = _pantalla

    private val _nivel = MutableStateFlow(CompressionLevel.MEDIO)
    val nivel: StateFlow<CompressionLevel> = _nivel

    private val _jobs = MutableStateFlow<List<JobItem>>(emptyList())
    val jobs: StateFlow<List<JobItem>> = _jobs

    private val _comprimiendo = MutableStateFlow(false)
    val comprimiendo: StateFlow<Boolean> = _comprimiendo

    private val _resultado = MutableStateFlow<ResultadoUi?>(null)
    val resultado: StateFlow<ResultadoUi?> = _resultado

    private val _biblioteca = MutableStateFlow<List<LibItem>>(emptyList())
    val biblioteca: StateFlow<List<LibItem>> = _biblioteca

    private val _consultaLib = MutableStateFlow("")
    val consultaLib: StateFlow<String> = _consultaLib

    fun setNivel(n: CompressionLevel) { _nivel.value = n }
    fun irA(p: Pantalla) { _pantalla.value = p }
    fun setConsulta(q: String) { _consultaLib.value = q }

    fun bibliotecaFiltrada(): List<LibItem> {
        val q = _consultaLib.value.trim().lowercase(Locale.ROOT)
        val base = _biblioteca.value
        return if (q.isEmpty()) base else base.filter { it.name.lowercase(Locale.ROOT).contains(q) }
    }

    /** Recibe los uris del selector y arma la lista de trabajos. */
    fun onFilesPicked(uris: List<Uri>) {
        val ctx = getApplication<Application>()
        val nuevos = uris.map { uri ->
            val (nombre, size) = consultarNombreYSize(ctx, uri)
            JobItem(uri = uri, nombre = nombre, antesBytes = size)
        }
        _jobs.value = nuevos
        _resultado.value = null
        _pantalla.value = Pantalla.Inicio
    }

    fun quitarJob(uri: Uri) {
        _jobs.value = _jobs.value.filterNot { it.uri == uri }
    }

    /** Lanza la compresión de todos los trabajos (en serie, por memoria). */
    fun comprimir() {
        if (_comprimiendo.value) return
        val ctx = getApplication<Application>()
        val nivel = _nivel.value
        _comprimiendo.value = true

        viewModelScope.launch {
            val lista = _jobs.value
            for (job in lista) {
                actualizar(job.uri) { it.copy(estado = EstadoJob.PROCESANDO, progreso = 0f, error = null) }
                try {
                    val res = withContext(Dispatchers.IO) {
                        PdfCompressor.compress(
                            context = ctx,
                            sourceUri = job.uri,
                            sourceName = job.nombre,
                            level = nivel
                        ) { done, total ->
                            val frac = if (total <= 0) 0f else done.toFloat() / total.toFloat()
                            actualizar(job.uri) { it.copy(progreso = frac) }
                        }
                    }
                    actualizar(job.uri) {
                        it.copy(
                            estado = EstadoJob.LISTO,
                            progreso = 1f,
                            paginas = res.pages,
                            antesBytes = res.beforeBytes,
                            despuesBytes = res.afterBytes,
                            salidaUri = res.outputUri,
                            salidaFile = res.outputFile
                        )
                    }
                } catch (e: Exception) {
                    val msg = e.message ?: "No se pudo comprimir el archivo."
                    actualizar(job.uri) { it.copy(estado = EstadoJob.ERROR, error = msg) }
                }
            }
            _comprimiendo.value = false

            // Resultado agregado
            val final = _jobs.value
            val thumb = final.firstOrNull { it.salidaUri != null || it.salidaFile != null }
                ?.let { withContext(Dispatchers.IO) { PdfCompressor.renderPreview(ctx, it.salidaUri, it.salidaFile) } }
                ?.let { it.asImageBitmap() }
            _resultado.value = ResultadoUi(
                jobs = final,
                totalAntes = final.sumOf { it.antesBytes },
                totalDespues = final.sumOf { it.despuesBytes },
                thumbnail = thumb
            )
            refreshLibrary()
            _pantalla.value = Pantalla.Resultado
        }
    }

    private fun actualizar(uri: Uri, fn: (JobItem) -> JobItem) {
        _jobs.value = _jobs.value.map { if (it.uri == uri) fn(it) else it }
    }

    fun refreshLibrary() {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            _biblioteca.value = withContext(Dispatchers.IO) { LibraryRepository.list(ctx) }
        }
    }

    fun eliminar(item: LibItem) {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { LibraryRepository.delete(ctx, item) }
            refreshLibrary()
        }
    }

    fun reset() {
        _jobs.value = emptyList()
        _resultado.value = null
        _pantalla.value = Pantalla.Inicio
    }

    private fun consultarNombreYSize(ctx: Context, uri: Uri): Pair<String, Long> {
        var nombre = "documento.pdf"
        var size = 0L
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val iN = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val iS = c.getColumnIndex(OpenableColumns.SIZE)
                if (c.moveToFirst()) {
                    if (iN >= 0) c.getString(iN)?.let { nombre = it }
                    if (iS >= 0 && !c.isNull(iS)) size = c.getLong(iS)
                }
            }
        } catch (_: Exception) { /* valores por defecto */ }
        return nombre to size
    }

    companion object {
        private val FMT = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("es"))
        fun fecha(ms: Long): String = try { FMT.format(Date(ms)) } catch (_: Exception) { "" }
    }
}
