package com.pdfcompresor.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pdfcompresor.app.ui.PdfIntents
import com.pdfcompresor.app.ui.components.IconoCarpeta
import com.pdfcompresor.app.ui.components.formatBytes
import com.pdfcompresor.app.ui.theme.Borde
import com.pdfcompresor.app.ui.theme.Rojo
import com.pdfcompresor.app.ui.theme.RojoDim
import com.pdfcompresor.app.ui.theme.RojoFuerte
import com.pdfcompresor.app.ui.theme.Superficie
import com.pdfcompresor.app.ui.theme.Superficie2
import com.pdfcompresor.app.ui.theme.Superficie3
import com.pdfcompresor.app.ui.theme.TextoAlto
import com.pdfcompresor.app.ui.theme.TextoBajo
import com.pdfcompresor.app.ui.theme.TextoMedio
import com.pdfcompresor.app.viewmodel.MainViewModel
import com.pdfcompresor.app.viewmodel.Pantalla
import kotlin.math.roundToInt

@Composable
fun ResultScreen(vm: MainViewModel) {
    val resultado by vm.resultado.collectAsStateWithLifecycle()
    val res = resultado

    LaunchedEffect(res) { if (res == null) vm.irA(Pantalla.Inicio) }
    if (res == null) return

    val exitosos = res.jobs.filter { it.salidaUri != null || it.salidaFile != null }
    val pct = if (res.totalAntes > 0)
        ((1 - res.totalDespues.toDouble() / res.totalAntes.toDouble()) * 100).roundToInt()
    else 0
    val nombreMostrado = if (res.jobs.size == 1) {
        res.jobs.first().nombre.substringBeforeLast('.') + "_comprimido.pdf"
    } else {
        "${exitosos.size} archivos comprimidos"
    }

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(14.dp))

        // ── Héroe ──
        Box(
            Modifier
                .size(74.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(RojoDim)
                .border(1.5.dp, RojoDim, RoundedCornerShape(24.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Check, null, tint = Rojo, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.height(14.dp))
        Box(
            Modifier
                .clip(RoundedCornerShape(99.dp))
                .background(RojoDim)
                .border(1.dp, RojoDim, RoundedCornerShape(99.dp))
                .padding(horizontal = 18.dp, vertical = 8.dp)
        ) {
            Text("−$pct%", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = RojoFuerte)
        }
        Spacer(Modifier.height(10.dp))
        Text(
            nombreMostrado, fontSize = 19.sp, fontWeight = FontWeight.Bold,
            color = TextoAlto, maxLines = 2, overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(6.dp))
        Text(
            buildAnnotatedString {
                append("Guardado en la carpeta ")
                withStyle(SpanStyle(color = RojoFuerte, fontWeight = FontWeight.Bold)) {
                    append("PDF compresor")
                }
                append(" listo para subir a la plataforma")
            },
            fontSize = 12.5.sp, color = TextoMedio,
            textAlign = TextAlign.Center, lineHeight = 17.sp
        )

        // ── Vista previa (1.ª página del PDF comprimido) ──
        res.thumbnail?.let { bmp ->
            Spacer(Modifier.height(14.dp))
            val alturaDp = (150f * bmp.height / bmp.width).dp
            Image(
                bitmap = bmp,
                contentDescription = "Vista previa del PDF comprimido",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .width(150.dp)
                    .height(alturaDp)
                    .clip(RoundedCornerShape(10.dp))
                    .border(1.dp, Borde, RoundedCornerShape(10.dp))
            )
            Spacer(Modifier.height(9.dp))
            Text("Vista previa · 1.ª página del PDF comprimido", fontSize = 10.5.sp, color = TextoBajo)
        }

        // ── Antes / después / páginas ──
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard(
                if (res.jobs.size == 1) formatBytes(res.jobs.first().antesBytes)
                else formatBytes(res.totalAntes),
                "ANTES", TextoAlto, Modifier.weight(1f)
            )
            StatCard(
                if (res.jobs.size == 1) formatBytes(res.jobs.first().despuesBytes)
                else formatBytes(res.totalDespues),
                "DESPUÉS", RojoFuerte, Modifier.weight(1f)
            )
            StatCard(
                "${res.jobs.sumOf { it.paginas }} pág", "PÁGINAS", TextoAlto, Modifier.weight(1f)
            )
        }

        // ── Ruta de guardado ──
        Spacer(Modifier.height(14.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Superficie)
                .border(1.dp, Borde, RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(IconoCarpeta, null, tint = Rojo, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                buildAnnotatedString {
                    append("Descargas / ")
                    withStyle(SpanStyle(color = TextoAlto, fontWeight = FontWeight.SemiBold)) {
                        append("PDF compresor")
                    }
                    append(
                        if (res.jobs.size == 1)
                            " / " + res.jobs.first().nombre.substringBeforeLast('.') + "_comprimido.pdf"
                        else " / ${exitosos.size} archivos"
                    )
                },
                fontSize = 11.5.sp, color = TextoMedio,
                maxLines = 2, overflow = TextOverflow.Ellipsis
            )
        }

        // ── Acciones ──
        Spacer(Modifier.height(14.dp))
        val primero = exitosos.firstOrNull()
        BotonPrincipal("Abrir PDF", enabled = primero != null) {
            primero?.let { PdfIntents.abrir(vm.getApplication(), it) }
        }
        Spacer(Modifier.height(10.dp))
        BotonSecundario("Compartir", enabled = primero != null) {
            primero?.let { PdfIntents.compartir(vm.getApplication(), it) }
        }
        Spacer(Modifier.height(10.dp))
        BotonSecundario("Ver en la biblioteca") {
            vm.refreshLibrary()
            vm.irA(Pantalla.Biblioteca)
        }
        Spacer(Modifier.height(10.dp))
        BotonSecundario("Comprimir otro") { vm.reset() }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun StatCard(valor: String, etiqueta: String, colorValor: Color, modifier: Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Superficie)
            .border(1.dp, Borde, RoundedCornerShape(14.dp))
            .padding(vertical = 13.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(valor, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = colorValor)
        Text(
            etiqueta, fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold,
            color = TextoBajo, letterSpacing = 0.5.sp, modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
private fun BotonPrincipal(texto: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Rojo,
            contentColor = Color.White,
            disabledContainerColor = Superficie2,
            disabledContentColor = TextoBajo
        ),
        modifier = Modifier.fillMaxWidth().height(54.dp)
    ) {
        Text(texto, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun BotonSecundario(texto: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Superficie2,
            contentColor = TextoAlto,
            disabledContainerColor = Superficie3,
            disabledContentColor = TextoBajo
        ),
        modifier = Modifier.fillMaxWidth().height(54.dp)
    ) {
        Text(texto, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}
