package com.pdfcompresor.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pdfcompresor.app.ui.theme.Rojo
import com.pdfcompresor.app.ui.theme.RojoDim
import com.pdfcompresor.app.ui.theme.TextoAlto
import com.pdfcompresor.app.ui.theme.TextoBajo
import java.util.Locale

/** Formatea bytes: 18.40 MB · 982 KB */
fun formatBytes(bytes: Long): String = when {
    bytes >= 1_000_000L -> String.format(Locale.US, "%.2f MB", bytes / 1_000_000.0)
    bytes > 0L -> "${bytes / 1000L} KB"
    else -> "0 KB"
}

/** Título de página centrado, sin logo ni puntos: «PDF Compresor» / «Biblioteca». */
@Composable
fun TituloPagina(texto: String) {
    Text(
        texto,
        fontSize = 17.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = (-0.3).sp,
        color = TextoAlto,
        textAlign = TextAlign.Center,
        modifier = Modifier.fillMaxWidth()
    )
}

/** Etiqueta de sección centrada: «NIVEL DE COMPRESSION». */
@Composable
fun SeccionLabel(texto: String) {
    Text(
        texto.uppercase(),
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        color = TextoBajo,
        letterSpacing = 1.2.sp,
        textAlign = TextAlign.Center,
        modifier = Modifier.fillMaxWidth()
    )
}

/** Miniatura de documento: caja roja tenue con el icono de PDF del prototipo. */
@Composable
fun IconoPdfBox(tam: Int = 36) {
    Box(
        modifier = Modifier
            .size(tam.dp)
            .clip(RoundedCornerShape((tam / 4).dp))
            .background(RojoDim),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            IconoDocumento,
            contentDescription = null,
            tint = Rojo,
            modifier = Modifier.size((tam * 0.5).dp)
        )
    }
}
