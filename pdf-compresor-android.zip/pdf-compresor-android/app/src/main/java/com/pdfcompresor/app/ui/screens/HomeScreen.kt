package com.pdfcompresor.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pdfcompresor.app.compress.CompressionLevel
import com.pdfcompresor.app.ui.components.IconoDocumento
import com.pdfcompresor.app.ui.components.IconoPdfBox
import com.pdfcompresor.app.ui.components.SeccionLabel
import com.pdfcompresor.app.ui.components.TituloPagina
import com.pdfcompresor.app.ui.components.formatBytes
import com.pdfcompresor.app.ui.theme.Borde
import com.pdfcompresor.app.ui.theme.BordeFuerte
import com.pdfcompresor.app.ui.theme.Rojo
import com.pdfcompresor.app.ui.theme.RojoDim
import com.pdfcompresor.app.ui.theme.RojoFuerte
import com.pdfcompresor.app.ui.theme.RojoProfundo
import com.pdfcompresor.app.ui.theme.Superficie
import com.pdfcompresor.app.ui.theme.Superficie2
import com.pdfcompresor.app.ui.theme.Superficie3
import com.pdfcompresor.app.ui.theme.TextoAlto
import com.pdfcompresor.app.ui.theme.TextoBajo
import com.pdfcompresor.app.ui.theme.VerdeOk
import com.pdfcompresor.app.viewmodel.EstadoJob
import com.pdfcompresor.app.viewmodel.JobItem
import com.pdfcompresor.app.viewmodel.MainViewModel
import kotlin.math.roundToInt

@Composable
fun HomeScreen(vm: MainViewModel, onPickFiles: () -> Unit, onCompress: () -> Unit) {
    val jobs by vm.jobs.collectAsStateWithLifecycle()
    val nivelSel by vm.nivel.collectAsStateWithLifecycle()
    val comprimiendo by vm.comprimiendo.collectAsStateWithLifecycle()

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp)
    ) {
        Spacer(Modifier.height(14.dp))
        TituloPagina("PDF Compresor")

        Spacer(Modifier.height(14.dp))
        ZonaSeleccion(enabled = !comprimiendo, onClick = onPickFiles)

        Spacer(Modifier.height(12.dp))
        jobs.forEach { job ->
            if (comprimiendo) FilaProgreso(job) else FilaArchivo(job) { vm.quitarJob(job.uri) }
            Spacer(Modifier.height(10.dp))
        }

        Spacer(Modifier.height(4.dp))
        SeccionLabel("Nivel de compresión")
        Spacer(Modifier.height(10.dp))

        CompressionLevel.entries.forEach { lvl ->
            TarjetaNivel(lvl, seleccionado = nivelSel == lvl) { vm.setNivel(lvl) }
            Spacer(Modifier.height(10.dp))
        }

        Spacer(Modifier.height(4.dp))
        BotonComprimir(comprimiendo, jobs.isNotEmpty(), onCompress)
        Spacer(Modifier.height(24.dp))
    }
}

/** Zona de selección con borde de guiones, igual que el prototipo. */
@Composable
private fun ZonaSeleccion(enabled: Boolean, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Superficie)
            .drawBehind {
                val r = CornerRadius(18.dp.toPx())
                val path = Path().apply {
                    addRoundRect(RoundRect(0f, 0f, size.width, size.height, r, r, r, r))
                }
                drawPath(
                    path,
                    color = BordeFuerte,
                    style = Stroke(
                        width = 1.5.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(
                            floatArrayOf(10.dp.toPx(), 7.dp.toPx())
                        )
                    )
                )
            }
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 26.dp, horizontal = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(RojoDim),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                IconoDocumento, contentDescription = null,
                tint = Rojo, modifier = Modifier.size(26.dp)
            )
        }
        Spacer(Modifier.height(10.dp))
        Text(
            "Toca para elegir un PDF",
            fontSize = 14.5.sp, fontWeight = FontWeight.Bold, color = TextoAlto
        )
    }
}

@Composable
private fun BotonComprimir(comprimiendo: Boolean, hayArchivos: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = hayArchivos && !comprimiendo,
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Rojo,
            contentColor = Color.White,
            disabledContainerColor = Superficie2,
            disabledContentColor = TextoBajo
        ),
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .shadow(
                elevation = if (hayArchivos && !comprimiendo) 10.dp else 0.dp,
                shape = RoundedCornerShape(14.dp),
                ambientColor = Rojo,
                spotColor = Rojo
            )
    ) {
        Text(
            if (comprimiendo) "Comprimiendo…" else "Comprimir PDF",
            fontSize = 15.5.sp, fontWeight = FontWeight.Bold
        )
    }
}

/** Fila de archivo elegido (antes de comprimir). */
@Composable
private fun FilaArchivo(job: JobItem, onQuitar: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Superficie)
            .border(1.dp, Borde, RoundedCornerShape(14.dp))
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconoPdfBox()
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(
                job.nombre, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                color = TextoAlto, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                formatBytes(job.antesBytes), fontSize = 11.sp, color = TextoBajo,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
        Box(
            Modifier
                .size(26.dp)
                .clip(CircleShape)
                .background(Superficie3)
                .clickable(onClick = onQuitar),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Filled.Clear, "Quitar",
                tint = TextoBajo, modifier = Modifier.size(13.dp)
            )
        }
    }
}

/** Fila con progreso por archivo durante la compresión. */
@Composable
private fun FilaProgreso(job: JobItem) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Superficie)
            .border(1.dp, Borde, RoundedCornerShape(14.dp))
            .padding(horizontal = 14.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        when (job.estado) {
            EstadoJob.LISTO -> {
                Box(
                    Modifier.size(20.dp).clip(CircleShape).background(Rojo),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Filled.Check, null,
                        tint = Color.White, modifier = Modifier.size(11.dp)
                    )
                }
            }
            EstadoJob.ERROR -> {
                Box(
                    Modifier.size(20.dp).clip(CircleShape).background(RojoProfundo),
                    contentAlignment = Alignment.Center
                ) {
                    Text("!", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            else -> CircularProgressIndicator(
                color = Rojo, strokeWidth = 2.5.dp, modifier = Modifier.size(20.dp)
            )
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(
                job.nombre, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold,
                color = TextoAlto, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            when (job.estado) {
                EstadoJob.LISTO -> Text(
                    "${formatBytes(job.antesBytes)} → ${formatBytes(job.despuesBytes)}",
                    fontSize = 11.sp, color = VerdeOk, modifier = Modifier.padding(top = 3.dp)
                )
                EstadoJob.ERROR -> Text(
                    job.error ?: "Error al comprimir",
                    fontSize = 11.sp, color = RojoFuerte, modifier = Modifier.padding(top = 3.dp),
                    maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                else -> Text(
                    "${(job.progreso * 100).roundToInt()}%",
                    fontSize = 11.sp, color = TextoBajo, modifier = Modifier.padding(top = 3.dp)
                )
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { job.progreso },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(RoundedCornerShape(99.dp)),
                color = if (job.estado == EstadoJob.LISTO) VerdeOk else Rojo,
                trackColor = Superficie3
            )
        }
    }
}

/** Tarjeta de nivel: radio + nombre + descripción, sin porcentajes. */
@Composable
private fun TarjetaNivel(nivel: CompressionLevel, seleccionado: Boolean, onSel: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(
                if (seleccionado)
                    Brush.horizontalGradient(listOf(RojoDim, Superficie))
                else
                    Brush.horizontalGradient(listOf(Superficie, Superficie))
            )
            .border(1.5.dp, if (seleccionado) Rojo else Borde, RoundedCornerShape(14.dp))
            .clickable(onClick = onSel)
            .padding(horizontal = 14.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(19.dp)
                .clip(CircleShape)
                .border(2.dp, if (seleccionado) Rojo else BordeFuerte, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (seleccionado) Box(Modifier.size(11.dp).clip(CircleShape).background(Rojo))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(nivel.titulo, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextoAlto)
            Text(
                nivel.descripcion, fontSize = 11.5.sp, color = TextoBajo,
                lineHeight = 15.sp, modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}
