package com.pdfcompresor.app.ui.theme

import androidx.compose.ui.graphics.Color

// Paleta minimalista negro + rojo (idéntica al prototipo web)
val Fondo = Color(0xFF0A0A0B)
val Superficie = Color(0xFF141416)
val Superficie2 = Color(0xFF1C1C1F)
val Superficie3 = Color(0xFF232327)
val Borde = Color(0xFF26262B)
val BordeFuerte = Color(0xFF33333A)

val Rojo = Color(0xFFE5484D)
val RojoFuerte = Color(0xFFFF5C61)
val RojoProfundo = Color(0xFFA52328)
val RojoDim = Color(0x24E5484D)

val TextoAlto = Color(0xFFF4F4F5)
val TextoMedio = Color(0xFFA1A1AA)
val TextoBajo = Color(0xFF63636C)
val VerdeOk = Color(0xFF7EE2A8)
