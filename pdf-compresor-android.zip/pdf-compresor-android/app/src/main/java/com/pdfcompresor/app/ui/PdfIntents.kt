package com.pdfcompresor.app.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.pdfcompresor.app.data.LibItem

/** Helpers para abrir y compartir los PDF comprimidos. */
object PdfIntents {

    fun abrir(context: Context, item: LibItem) {
        val uri = item.contentOrFile(context)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(context, "No hay un visor de PDF instalado", Toast.LENGTH_SHORT).show()
        }
    }

    fun compartir(context: Context, item: LibItem) {
        val uri = item.contentOrFile(context)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            context.startActivity(Intent.createChooser(intent, "Compartir PDF con"))
        } catch (_: Exception) {
            Toast.makeText(context, "No se pudo compartir", Toast.LENGTH_SHORT).show()
        }
    }
}
