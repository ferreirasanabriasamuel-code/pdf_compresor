package com.pdfcompresor.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val EsquemaOscuro = darkColorScheme(
    primary = Rojo,
    onPrimary = Color.White,
    primaryContainer = RojoProfundo,
    onPrimaryContainer = Color.White,
    secondary = RojoFuerte,
    onSecondary = Color.White,
    background = Fondo,
    onBackground = TextoAlto,
    surface = Superficie,
    onSurface = TextoAlto,
    surfaceVariant = Superficie2,
    onSurfaceVariant = TextoMedio,
    outline = BordeFuerte,
    error = RojoFuerte,
    onError = Color.White
)

/** Tema fijo en oscuro: la app no tiene selector de modo claro. */
@Composable
fun PDFCompresorTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = EsquemaOscuro,
        typography = Typography(),
        content = content
    )
}
