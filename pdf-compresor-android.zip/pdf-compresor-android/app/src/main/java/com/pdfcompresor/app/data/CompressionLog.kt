package com.pdfcompresor.app.data

import android.content.Context
import org.json.JSONObject

/**
 * Registro local (SharedPreferences) de cada compresión: nombre final del
 * archivo → tamaño original y nº de páginas. Permite a la Biblioteca mostrar
 * «−65% · 10 pág» junto al peso y la fecha, igual que el prototipo.
 */
object CompressionLog {

    private const val PREFS = "registro_compresion"

    fun put(context: Context, nombreFinal: String, antesBytes: Long, paginas: Int) {
        if (nombreFinal.isBlank()) return
        val json = JSONObject().put("b", antesBytes).put("p", paginas)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(nombreFinal, json.toString()).apply()
    }

    /** (antesBytes, páginas) o null si no hay registro para ese nombre. */
    fun get(context: Context, nombreFinal: String): Pair<Long, Int>? = try {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(nombreFinal, null) ?: return null
        val o = JSONObject(raw)
        o.getLong("b") to o.getInt("p")
    } catch (_: Exception) {
        null
    }
}
