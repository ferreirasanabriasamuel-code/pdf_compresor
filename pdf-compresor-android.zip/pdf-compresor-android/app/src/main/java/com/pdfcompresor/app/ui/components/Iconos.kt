package com.pdfcompresor.app.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathBuilder
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * Iconos vectoriales propios (mismos trazados del prototipo web) para no
 * necesitar material-icons-extended y mantener la APK ligera.
 */

private fun buildIconoDocumento(block: PathBuilder.() -> Unit): ImageVector =
    ImageVector.Builder(
        name = "IconoDocumento",
        defaultWidth = 24.dp, defaultHeight = 24.dp,
        viewportWidth = 24f, viewportHeight = 24f
    ).path(
        fill = SolidColor(Color.White),
        fillAlpha = 1f,
        pathFillType = PathFillType.EvenOdd,
        pathBuilder = block
    ).build()

/** Documento con esquina doblada y dos líneas (icono «PDF» del prototipo). */
val IconoDocumento: ImageVector = buildIconoDocumento {
    // cuerpo con esquina cortada
    moveTo(14f, 2f)
    lineTo(6f, 2f)
    quadTo(4f, 2f, 4f, 4f)
    lineTo(4f, 20f)
    quadTo(4f, 22f, 6f, 22f)
    lineTo(18f, 22f)
    quadTo(20f, 22f, 20f, 20f)
    lineTo(20f, 8f)
    close()
    // hueco interior (efecto de contorno)
    moveTo(6f, 4f)
    lineTo(13f, 4f)
    lineTo(13f, 9f)
    lineTo(18f, 9f)
    lineTo(18f, 20f)
    lineTo(6f, 20f)
    close()
    // líneas de texto
    moveTo(8f, 12f)
    lineTo(16f, 12f)
    lineTo(16f, 13.6f)
    lineTo(8f, 13.6f)
    close()
    moveTo(8f, 15.2f)
    lineTo(16f, 15.2f)
    lineTo(16f, 16.8f)
    lineTo(8f, 16.8f)
    close()
}

/** Carpeta rellena (icono «Biblioteca» del prototipo). */
val IconoCarpeta: ImageVector = ImageVector.Builder(
    name = "IconoCarpeta",
    defaultWidth = 24.dp, defaultHeight = 24.dp,
    viewportWidth = 24f, viewportHeight = 24f
).path(
    fill = SolidColor(Color.White),
    pathBuilder = {
        moveTo(10f, 4f)
        lineTo(4f, 4f)
        quadTo(2f, 4f, 2f, 6f)
        lineTo(2f, 18f)
        quadTo(2f, 20f, 4f, 20f)
        lineTo(20f, 20f)
        quadTo(22f, 20f, 22f, 18f)
        lineTo(22f, 8f)
        quadTo(22f, 6f, 20f, 6f)
        lineTo(12f, 6f)
        close()
    }
).build()
