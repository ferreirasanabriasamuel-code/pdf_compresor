# PDF Compresor · APK ligera, offline y sin anuncios

App Android **nativa (Kotlin + Jetpack Compose)** para comprimir PDFs pesados a
menos de **1 MB**, pensada para subir tareas y proyectos a plataformas de
evaluación con límite de tamaño.

- 🔒 **100% offline**: los PDF nunca salen del dispositivo (cero SDKs de terceros).
- 🚫 **Sin anuncios, sin suscripciones, sin rastreadores**.
- 🎚️ **3 niveles**: Ligero / Medio / Agresivo (nombre + descripción, como el prototipo).
- 📑 **Uno o varios PDF** de una vez (el selector del sistema permite marcar varios), con progreso por archivo.
- 👁️ **Vista previa** de la 1.ª página del PDF comprimido.
- 🗂️ **Biblioteca**: todo queda en `Descargas/PDF compresor`, con búsqueda, −% de ahorro, páginas y fecha.
- 🌙 **Tema oscuro fijo** negro + rojo (`#E5484D`), tipografía del sistema (Roboto).
- 📱 **Ícono adaptativo vectorial** (no usa PNG): diseño vectorizado del ícono original.

> La interfaz replica el prototipo web definitivo: `prototipo-ui.html`.

---

## Cómo generar la APK con GitHub (sin instalar nada)

### Opción A · Subir solo el zip (la más simple) ✅

1. Crea un repositorio nuevo en [github.com](https://github.com).
2. Crea el workflow con **Add file → Create new file**: escribe exactamente
   `.github/workflows/build-from-zip.yml` como nombre y pega el contenido de
   **`docs/workflow-desde-zip.yml`** (copia visible).
   *Se hace una sola vez; a partir de ahí no vuelves a tocar carpetas ocultas.*
3. Pulsa **Add file → Upload files** y sube **únicamente
   `pdf-compresor-android.zip`**. Al guardarse, el workflow **«Compilar APK
   (desde zip)»** arranca solo.
4. Espera ~4–6 min → entra en **Actions** → abre la corrida → en **Artifacts**
   descarga `pdf-compresor-apk`:
   - `app-release.apk` → **la que instalas** (firmada con la llave del zip, lista para usar).
   - `app-debug.apk` → alternativa de pruebas.
5. Copia la APK al celular e instálala (activa «instalar apps de orígenes
   desconocidos» cuando te lo pida). Para actualizar más adelante, sube el
   zip de nuevo: cada subida dispara una compilación nueva.

> **¿Cómo funciona?** El workflow detecta cualquier `.zip` en la raíz del
> repo, lo descomprime, localiza el proyecto por su `gradlew`, le devuelve el
> permiso de ejecución y compila. Los archivos ocultos no hacen falta
> subirlos aparte: ya van dentro del zip.

### Opción B · Subir el proyecto completo (con git)

Si usas `git push`, sube **todo el contenido de este proyecto**, incluyendo la
carpeta oculta `.github/`, `gradlew` y `debug.keystore`; el workflow
**«Compilar APK»** corre en cada push. La subida web por drag & drop suele
omitir archivos ocultos — por eso la opción A es más segura.

**Por qué el build no falla:** las versiones están bloqueadas entre sí
(Gradle 8.6 ↔ AGP 8.4.2 ↔ JDK 17 ↔ Compose BOM 2024.06.00), `gradlew` recibe
`chmod +x` antes de compilarse y el proyecto trae su propio `debug.keystore`,
así la firma es siempre la misma y las actualizaciones se instalan encima sin
desinstalar.

### ⚠️ ¿No ves el workflow? (carpeta `.github` oculta)

Los workflows viven en **`.github/workflows/`** — una carpeta que empieza con
punto y por eso muchos exploradores de archivos (y la subida por drag & drop
de la web de GitHub) la ocultan o la omiten. Por eso cada workflow tiene una
copia visible en `docs/`:

| Workflow | Archivo real (oculto) | Copia visible |
|---|---|---|
| Compilar APK (desde zip) | `.github/workflows/build-from-zip.yml` | `docs/workflow-desde-zip.yml` |
| Compilar APK (proyecto completo) | `.github/workflows/build-apk.yml` | `docs/workflow-github-actions.yml` |

- **Si subes con git** (`git add . && git push`), se incluyen solos. ✅
- **Si subes por la web de GitHub**, crea cada archivo a mano:
  **Add file → Create new file**, escribe el nombre exacto de la columna
  central y pega el contenido de la copia visible. Al guardar, la pestaña
  Actions ya tendrá los workflows.
- Para ver carpetas ocultas: Windows Explorer ✅ las muestra; macOS Finder
  `Cmd + Shift + .`; Linux `Ctrl + H`.

## Cómo comprime

El motor usa las **APIs nativas de Android** (`PdfRenderer` + `PdfDocument`):
re-renderiza cada página a JPEG con la resolución y calidad del nivel elegido
(Ligero 150 dpi/q80 · Medio 110 dpi/q60 · Agresivo 85 dpi/q45) y reconstruye
el PDF. Es la misma técnica de las apps de referencia, sin dependencias
externas ni envío de datos. Si el archivo ya es pequeño, el resultado puede
no reducirse — la app muestra siempre el antes/después real.

## Desarrollo local (opcional)

- Requisitos: Android Studio (con JDK 17) o Gradle 8.6 + SDK Android 34.
- Abre la carpeta del proyecto en Android Studio y ejecuta `app`.
- La firma de ambas variantes usa `debug.keystore` (contraseñas `android`,
  alias `androiddebugkey`) — no lo borres si quieres actualizar la app instalada.

## Estructura

```
app/src/main/java/com/pdfcompresor/app/
├── MainActivity.kt            # navegación Inicio · Biblioteca
├── compress/                  # motor de compresión + niveles
├── data/                      # biblioteca (MediaStore) + registro de compresión
├── ui/
│   ├── components/            # iconos vectoriales propios y piezas comunes
│   ├── screens/               # Home · Resultado · Biblioteca
│   └── theme/                 # paleta negro+rojo, tema oscuro fijo
└── viewmodel/                 # estado del flujo de compresión
```
