# Análisis de ingeniería inversa — «Compress PDF files – Reduce file size»

APK analizada: `Compress PDF files - Reduce file size.apk` (21 MB, v36,
objetivo Android 15 / API 36). El objetivo del análisis fue entender **cómo
comprime** y **qué evitamos reutilizar**, no copiar su código (está compilado
y ofuscado, y sería ilegal reutilizarlo).

## 1. Identidad

| Campo | Valor |
|---|---|
| Paquete | `smartapps38.pdf.compressor.compress.file.pdf` |
| Nombre | Compress PDF files – Reduce file size |
| Versión | 36 (versionCode 36) |
| minSdk / targetSdk | 5 (!) / 36 |
| Tamaño del APK | 21 MB (4 archivos dex, ~21 MB de código) |

## 2. Tecnología

- Construida con **B4X / B4A (Basic4Android)**: se identificó por los layouts
  `.bal` en `assets/` (b4x_fontawesome.otf, b4x_materialicons.ttf,
  templates de diálogos, etc.) y clases del runtime B4A
  (`b4xset`, `b4xdialog`, `b4xswitch`, `b4xseekbar`, `swiftbutton`, …).
- El código «Basic» se compila a clases Java ofuscadas; no se recupera fuente,
  pero el comportamiento queda claro por los recursos y clases envolventes.

## 3. Motor de compresión (lo que sí copiamos como idea)

- Usa las **APIs nativas de Android**: `android.graphics.pdf.PdfDocument`
  (reconstrucción) y compresión **JPEG** de las páginas re-renderizadas.
  No se detectaron librerías PDF de terceros (ni PDFBox, ni iText, ni
  PDFium/MuPDF embebidos) — no tiene librerías nativas `.so` en absoluto.
- Estados visibles: `Compressing PDF...`, `Choose pdf file`,
  `lbl_filenamesize`, barra de progreso numérica (NumberProgressBar),
  botones `btn_convert` / `btn_downloadmain`.
- Es decir: **misma técnica que adoptamos** (re-render + JPEG + reconstruir),
  que funciona 100% offline.

## 4. Interfaz (referencia visual)

- Pantalla principal con selector de archivo, etiqueta de tamaño y progreso.
- `pnl_album`: una **galería/biblioteca** de los archivos procesados
  (`item_dl.bal` con miniatura, título y descripción) — idea que conservamos
  y mejoramos como pestaña «Biblioteca» con carpeta dedicada.
- Navigation drawer con plantillas `.bal` (datepicker, dialogs, seekbar,
  combobox, roundslider…).

## 5. Lo fastidioso (y que nuestra app NO lleva)

Clase `clsadmob` + properties de SDKs encontrados en el APK:

- **Google AdMob** (`play-services-ads`, `firebase-ads`) con **banners**
  (`pnl_bannerads`), **intersticiales** y **anuncios recompensados** (el dex
  contiene mensajes tipo «The rewarded ad wasn't ready yet»).
- **Firebase Analytics / Measurement** (telemetría).
- **User Messaging Platform** (formularios de consentimiento GDPR).
- `httpjob` (llamadas HTTP para anuncios/actualizaciones).

Eso explica el tamaño de 21 MB: la mayoría es SDK de anuncios y analytics.
**Nuestra app no declara permiso de INTERNET**, no incluye ningún SDK de
terceros y su APK será drásticamente más pequeña.

## 6. Conclusiones aplicadas a PDF Compresor

1. Misma técnica de compresión (re-render a dpi + JPEG + PdfDocument) → offline.
2. Interfaz inspirada en su flujo (elegir → nivel → progreso → resultado →
   biblioteca) con diseño propio negro/rojo minimalista.
3. Sin AdMob/Firebase/analytics/consentimientos → sin anuncios ni suscripciones.
4. Carpeta dedicada «PDF compresor» en Descargas + biblioteca integrada.
5. Niveles de compresión configurables y soporte multi-archivo con progreso.
